import React from 'react'

function Tutorials() {
    return (
        <div className='min-vh'>
            <h1>This is Tutorials</h1>
        </div>
    )
}

export default Tutorials;
