import React from 'react'
import { ServicesCard } from '../component/ServicesCard';
import '../App.css';
import '../Css/Home.css';

function Home() {
    const cardDetails = [
        {
            title: 'Services',
            details: "suno madrjatttt gand marao phrrr",
            path: '/tutorials/1'
        },
        {
            title: 'Services',
            details: "suno madrjatttt gand marao phrrr",
            path: '/services/2'
        },

        {
            title: 'Services',
            details: "suno madrjatttt gand marao phrrr",
            path: '/contact/3'
        },]

    return (
        <div className='card-container'>
            <h1 className='name'>Owner Name</h1>
            <div className='row justify-between'>
                {cardDetails.map((item, index) => (
                    <ServicesCard {...item} key={index.toString()} />
                ))
                }
            </div>
        </div>
    )
}

export default Home;
